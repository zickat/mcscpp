//#include <jni.h>
#include <string>
#include "dtw.h"
#include "WavToMfcc.h"
#include <stdio.h>
#include <stdlib.h>
#include <sstream>
#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <vector>

using namespace std;

char * fichier(std::string ordre, std::string locuteur){
    std::stringstream ss;
    ss << "corpus/dronevolant_nonbruite/" << locuteur << "_" << ordre << ".wav";
    //printf("%s\n", ss.str().c_str());
    return strdup(ss.str().c_str());
}

void getMyMFCC(char * filename, float *** buffer, int * size){
    struct wavfile mywav;
    FILE * f;

    wavRead(&f, filename, &mywav);

    int16_t ** bufferSilence;
    int newLength;

	printf("%d \n", mywav.bytes_in_data/sizeof(int16_t));
	//fseek(f, 0, SEEK_END);
	//printf("%d \n", ftell(f));
	

    vector<int16_t> wavbuffer(mywav.bytes_in_data/sizeof(int16_t));
    int16_t b;
    
    printf("%d\n", wavbuffer.size());
    
    int i = 0;

	while(fread(&b, sizeof(int16_t), 1, f) > 0){
		//printf("%d %d\n", i, b);
		wavbuffer[i++] = b;
		//printf("%d %d\n", i, b);
	}

   //int n = fread(wavbuffer, sizeof(int16_t), mywav.bytes_in_data/sizeof(int16_t), f);

    //removeSilence(&wavbuffer[0], mywav.bytes_in_data/sizeof(int16_t), bufferSilence, &newLength, 0.001);
    //delete(wavbuffer);

    //computeMFCC(*buffer, size, * bufferSilence, newLength, mywav.frequency, 512, 256, 13, 26);
    computeMFCC(*buffer, size, &wavbuffer[0], mywav.bytes_in_data/sizeof(int16_t), mywav.frequency, 512, 256, 13, 26);
    //delete(bufferSilence);
}


// jstring Java_com_example_benjidu11_projetmcsrecovocale_MainActivity_resolveWord(
//         JNIEnv *env,
//         jobject /* this */,
//         jstring file) {
int main(int argc, char const *argv[]){

    std::string vocabulaire[] = {"arretetoi", "atterrissage", "avance", "decollage", "droite", "etatdurgence", "faisunflip", "gauche", "plusbas", "plushaut", "recule", "tournedroite", "tournegauche"};
    std::string locuteur = "Aym";
    char * filename = fichier(vocabulaire[0], locuteur);
    char * test = fichier(vocabulaire[0], "M01");

    float ** buff1;
    float ** buff2;
    int size1;
    int size2;

    //getMyMFCC(filename, &buff1, &size1);
    getMyMFCC(test, &buff2, &size2);

    float cout = dtw(size1, size2, 12, *buff1, *buff2);

    std::stringstream ss;
    ss << cout;

    //return env->NewStringUTF(ss.str().c_str());
    return 0;
}

/*int main(int argc, char const *argv[])
{
    std::string vocabulaire[] = {"arretetoi", "atterrissage", "avance", "decollage", "droite", "etatdurgence", "faisunflip", "gauche", "plusbas", "plushaut", "recule", "tournedroite", "tournegauche"};
    std::string locuteur = "Aym";
    char * filename = fichier(vocabulaire[0], locuteur);
    wavfile mywav;
    FILE * f;
    dtw(0,0,0, NULL, NULL);
    //wavRead(&f, filename, &mywav);
    return 0;
}*/
