//
// Created by valen on 22/10/2016.
//

#ifndef PROJETMCS_DTW_H_H
#define PROJETMCS_DTW_H_H

    float dtw(int n_ck, int n_cunk, int dim_mfcc, float* c_k, float* c_unk);

#endif //PROJETMCS_DTW_H_H
