/*******************************************************************************
 *
 * Drone control through voice recognition -- PC to drone communication
 * Team GYTAM, feb. 2016
 *
 *
 ******************************************************************************/

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h> // for memcmp
#include <stdint.h> // for int16_t and int32_t
#include <math.h>
#include <iostream>
#include "dtw.h"
#include <limits>

void min(float * tabTest, int nb, float * valMin, float * indMin);

float distanceMatricielle(float * matrice1, int size1, float * matrice2, int size2);

int size(int indice, int dim_mfcc, int fin);

/**
* Dtw function that given two matrix of cep coefficient computes distance
* between those two signals.
*  @param n_ck      Dimension of unknow signal
*  @param n_cunk    Dimension of know signal
*  @param dim_mfcc  Size of nfcc decompostion base
*  @param c_k       Matrix of know signal
*  @param c_unk     Matrix of unknow signal
*  @return Distance between the two signals
*/

float dtw(int n_ck, int n_cunk, int dim_mfcc, float* c_k, float* c_unk) {

    float ** g;
    float distance;
    float inf = std::numeric_limits<float>::max();
    float testmin[3];
    float indMin;

    //g = (float**)malloc((n_ck+1)* sizeof(float *));
    g = new float * [dim_mfcc + 1];
    for (int i = 0; i < dim_mfcc; ++i) {
        //g[i] = (float*)malloc((n_cunk+1)* sizeof(float));
        g[i] = new float(dim_mfcc + 1);
    }

    g[0][0] = 0;
    for (int i = 1; i < dim_mfcc+1; ++i) {
        g[0][i] = inf;
    }

    for (int i = 1; i < n_ck+1; i += n_ck/dim_mfcc) {
        g[i][0] = inf;
        for (int j = 1; j < n_cunk + 1; j += n_cunk/dim_mfcc) {
            distance = distanceMatricielle(&c_k[i], size(i, n_ck/dim_mfcc, n_ck), &c_unk[i], size(i, n_cunk/dim_mfcc, n_cunk));
            testmin[0] = g[i-1][j] + distance;
            testmin[1] = g[i-1][j-1] + distance;
            testmin[2] = g[i][j-1] + distance;
            min(testmin, 3, &g[i][j], &indMin);
        }
    }

    return g[n_ck+1][n_cunk+1]/(n_ck + n_cunk);

}

void min(float * tabTest, int nb, float * valMin, float * indMin){
    *valMin = std::numeric_limits<float>::min();
    for (int i = 0; i < nb; ++i) {
        if(tabTest[i] < *valMin){
            *valMin = tabTest[i];
            *indMin = i;
        }
    }
}

float distanceMatricielle(float * matrice1, int size1, float * matrice2, int size2){
    float summ = 0;
    int i;
    for (i = 0; i < size1 && i < size2; ++i) {
        summ += (matrice1[i] - matrice2[i])*(matrice1[i] - matrice2[i]);
    }
    for(; i < size1; ++i){
        summ += matrice1[i]*matrice1[i];
    }
    for(; i < size2; ++i){
        summ += matrice2[i]*matrice2[i];
    }
    return (float)sqrt(summ);
}

int size(int indice, int dim_mfcc, int fin){
    if(indice + dim_mfcc > fin){
        return dim_mfcc + indice - fin;
    }
    return dim_mfcc;
}